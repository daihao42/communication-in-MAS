## Neighborhood-oriented Decentralized Learning Communication in Multi-Agent System


## TODO

- [x] Distributed communication
- [] Fed-Avg algorithm support
- [x] Loggin and tensorboard
